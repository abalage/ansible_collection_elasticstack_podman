curl -LO https://github.com/elastic/beats/raw/7.14/filebeat/filebeat.reference.yml
