https://raw.githubusercontent.com/elastic/elasticsearch/7.15/distribution/src/config/log4j2.properties
https://raw.githubusercontent.com/elastic/elasticsearch/7.15/x-pack/plugin/core/src/main/config/log4j2.properties
